package com.telusko.springmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.telusko.springmvc.model.Alien;

@Controller
public class HomeController {
	
	@Autowired
	AlienRepo repo;
	
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	
	@PostMapping(value="/addAliens")
	public String addAliens(@ModelAttribute("a1") Alien a)
	{
		repo.save(a);
		return "result";
	}
	
	@GetMapping(value="/findByUser")
	public String findByUser(@RequestParam int aid, Model m)
	{
		m.addAttribute("result", repo.findById(aid));
		return "show";
	}
	
	@GetMapping(value="/showAliens")
	public String showAliens(Model m)
	{
		m.addAttribute("result", repo.findAll());
		return "show";
	}
	


}
