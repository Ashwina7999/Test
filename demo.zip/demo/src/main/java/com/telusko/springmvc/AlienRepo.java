package com.telusko.springmvc;

import org.springframework.data.jpa.repository.JpaRepository;
import com.telusko.springmvc.model.Alien;

public interface AlienRepo extends JpaRepository<Alien, Integer> {

}
